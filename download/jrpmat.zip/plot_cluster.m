function hNode =  plot_cluster(x,y,components)

% PLOT_CLUSTER - plot network components in a given 2D-Space
%
%
% Required inputs:
%	x = x-coordinates of the nodes
%	y = y-coordinates of the nodes
%	mod = cell array encoding components (cf. nwcomp.m)
%
% Output:
%	h = handles of the individual nodes
%
%
% Requires:  
%
% See also: nwcomp.m

%
% Copyright (C) 2011 Stefan Schinkel, schinkel@physik.hu-berlin.de 
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.


%clear current plot
cla
% enable hold
hold on;

% make a colour map
cMap = jet(length(x));

% plot all electrodes as circles
for i=1:length(x)
		h(i)=plot(x(i),y(i),'ok','MarkerSize',15,'MarkerFaceColor','w');
end

%colour the electrodes accourding to components in 
if length(components) > 1
	for i=1:length(components)
		theComponent = components{i};
		if length(theComponent) > 1
			set(h(theComponent),'MarkerFaceColor',cMap(theComponent(1),:))
		end
	end
end

set(gca,'YDir','reverse')
axis square
axis off

